#include <iostream>

double division(int x, int y){
    return x/y;
}

int main() {
    std::cout << division(6,5) << std::endl;
    return 0;
}